import java.util.ArrayList;

public class Main1 {

	public static void main(String[] args) {
		
		ArrayList<Student> list = new ArrayList<Student>();
		
		Student s1 = new Student("12345678X", "中村", 136);
		InternationalStudent is1 =
				new InternationalStudent("18992311X", "Jackson", 84, "アメリカ", false);
		WorkingStudent ws1 = new WorkingStudent("11223344T", "佐藤", 36, "滋賀銀行");
		
		list.add(s1);
		list.add(is1);
		list.add(ws1);
	
		for(Student s: list) {
			s.hello();
			s.graduate();
			s.addCredit(50);
			System.out.println(s.toString());
			System.out.println();
		}
	
	
	}

}
