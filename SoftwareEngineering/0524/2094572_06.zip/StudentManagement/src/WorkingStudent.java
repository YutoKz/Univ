
public class WorkingStudent extends Student {

	private String company;

	
	
	public WorkingStudent() {
		super();
	}

	public WorkingStudent(String id, String name, int credit, String company) {
		super(id, name, credit);
		this.setCompany(company);
	}

	
	
	public void explain() {
		System.out.print("私" + getName() + "は，" + company + "に勤務する社会人学生です。");
		System.out.println();
	}

	@Override
	public void hello() {
		super.hello();
		this.explain();
	}

	

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	
	
	@Override
	public String toString() {
		return String.format("%s\t%s\t%4d単位\t%s所属", getId(), getName(), getCredit(), getCompany());
	}
	
}
