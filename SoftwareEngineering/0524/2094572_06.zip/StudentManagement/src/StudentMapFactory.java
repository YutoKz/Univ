import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;

public class StudentMapFactory {

	public static TreeMap<String, Student> create(String fileName) {

		TreeMap<String, Student> map = new TreeMap<String, Student>();

		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line;

			while ((line = br.readLine()) != null) {
				String[] data = line.split(",");
			
				switch(data[3]) {
				case "0":
					Student s = new Student(data[0], data[1], Integer.parseInt(data[2]));
					map.put(data[0], s);
					break;
				case "1":
					InternationalStudent is = new InternationalStudent(data[0], data[1], Integer.parseInt(data[2]), data[4], ((data[5] == "1")? true : false));
					map.put(data[0], is);
					break;
				case "2":
					WorkingStudent ws = new WorkingStudent(data[0], data[1], Integer.parseInt(data[2]), data[4]);
					map.put(data[0], ws);
					break;
				}
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			System.err.println("error : ファイルが見つかりません　終了");
			System.exit(1);
		} catch (IOException e) {
			System.err.println("error : 入出力例外　終了");
			System.exit(1);
		}

		return map;
	}
}
