
public abstract class PixelArt implements Drawable{
	
	public PixelArt()
	{
		
	}
}
