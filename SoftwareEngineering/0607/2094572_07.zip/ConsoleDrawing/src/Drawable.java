
public interface Drawable {
	
	public abstract void draw();
}
