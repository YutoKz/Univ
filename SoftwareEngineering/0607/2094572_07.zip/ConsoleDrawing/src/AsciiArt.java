
public abstract class AsciiArt implements Drawable{
	
	public AsciiArt()
	{
		
	}
	
}
